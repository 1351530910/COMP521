#include <wtypes.h>
#include "Exports.h"

int UnityMain(HINSTANCE /*hInstance*/, HINSTANCE /*hPrevInstance*/, LPWSTR /*lpCmdLine*/, int /*nShowCmd*/)
{
    return 0;
}
