
the out of screen boundary value is computed using Screen.Width and Screen.Height and a constant specified in camera properties

control is w/s for cannon, space for shooting
the ghost has an initial shape, and only influenced by rigid transformations
collision reaction depends on the incident angle, either angular drag or translation force.